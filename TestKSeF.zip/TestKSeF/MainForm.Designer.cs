﻿namespace TestKSeF
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.Configuration_listBox = new System.Windows.Forms.ListBox();
            this.configurationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.AuthorisationChallenge_button = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Challenge_textBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Timestamp_textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ReferenceNo_textBox = new System.Windows.Forms.TextBox();
            this.InitToken_button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TokenSesji_textBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.GetStatus2_button = new System.Windows.Forms.Button();
            this.GetStatus_button = new System.Windows.Forms.Button();
            this.Status_textBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Terminate_button = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Invoice1_RefNo_textBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Invoice1_Dlg_button = new System.Windows.Forms.Button();
            this.Invoice1_textBox = new System.Windows.Forms.TextBox();
            this.Invoice1_button = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.GetInvoice1_CorrReason_textBox = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.GetInvoice1_CorrNumber_textBox = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.GetInvoice1AndCorrect_button = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.GetInvoice1_FileName_button = new System.Windows.Forms.Button();
            this.KSefRefNo_textBox = new System.Windows.Forms.TextBox();
            this.GetInvoice_FileName_textBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.GetInvoice1_button = new System.Windows.Forms.Button();
            this.GetInvoice1_textBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.InvoiceStatus_button = new System.Windows.Forms.Button();
            this.InvoiceStatus_textBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.QueryHeader_Subject2_radioButton = new System.Windows.Forms.RadioButton();
            this.QueryHeader_Subject1_radioButton = new System.Windows.Forms.RadioButton();
            this.QueryHeader_PageNo_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.QueryHeader_textBox = new System.Windows.Forms.TextBox();
            this.QueryHeader_button = new System.Windows.Forms.Button();
            this.QueryHeader_ToDate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.QueryHeader_FromDate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.QueryFiles_File_button = new System.Windows.Forms.Button();
            this.QueryFiles_File_textBox = new System.Windows.Forms.TextBox();
            this.QueryFiles_Get_button = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.QueryFiles_Status_button = new System.Windows.Forms.Button();
            this.QueryFiles_Status_textBox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.QueryFiles_RefNo_textBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.QueryFiles_Init_button = new System.Windows.Forms.Button();
            this.QueryFiles_ToDate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.QueryFiles_FromDate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.Batch_SignFile_button = new System.Windows.Forms.Button();
            this.Batch_SignFile_textBox = new System.Windows.Forms.TextBox();
            this.Batch_Send_button = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.Batch_MaxSize_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.Batch_ZipFile_button = new System.Windows.Forms.Button();
            this.Batch_ZipFile_textBox = new System.Windows.Forms.TextBox();
            this.Batch_Init_button = new System.Windows.Forms.Button();
            this.Configuration_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.configurationBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.QueryHeader_PageNo_numericUpDown)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Batch_MaxSize_numericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Konfiguracja:";
            // 
            // Configuration_listBox
            // 
            this.Configuration_listBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Configuration_listBox.DataSource = this.configurationBindingSource;
            this.Configuration_listBox.DisplayMember = "OurFullName";
            this.Configuration_listBox.FormattingEnabled = true;
            this.Configuration_listBox.ItemHeight = 15;
            this.Configuration_listBox.Location = new System.Drawing.Point(95, 24);
            this.Configuration_listBox.Name = "Configuration_listBox";
            this.Configuration_listBox.Size = new System.Drawing.Size(1020, 64);
            this.Configuration_listBox.TabIndex = 1;
            // 
            // AuthorisationChallenge_button
            // 
            this.AuthorisationChallenge_button.Location = new System.Drawing.Point(6, 22);
            this.AuthorisationChallenge_button.Name = "AuthorisationChallenge_button";
            this.AuthorisationChallenge_button.Size = new System.Drawing.Size(446, 23);
            this.AuthorisationChallenge_button.TabIndex = 2;
            this.AuthorisationChallenge_button.Text = "Nawiąż sesję";
            this.AuthorisationChallenge_button.UseVisualStyleBackColor = true;
            this.AuthorisationChallenge_button.Click += new System.EventHandler(this.AuthorisationChallenge_button_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Challenge_textBox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Timestamp_textBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.AuthorisationChallenge_button);
            this.groupBox1.Location = new System.Drawing.Point(12, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(458, 117);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Nawiązanie sesji";
            // 
            // Challenge_textBox
            // 
            this.Challenge_textBox.Location = new System.Drawing.Point(98, 80);
            this.Challenge_textBox.Name = "Challenge_textBox";
            this.Challenge_textBox.Size = new System.Drawing.Size(354, 23);
            this.Challenge_textBox.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Challenge:";
            // 
            // Timestamp_textBox
            // 
            this.Timestamp_textBox.Location = new System.Drawing.Point(98, 51);
            this.Timestamp_textBox.Name = "Timestamp_textBox";
            this.Timestamp_textBox.Size = new System.Drawing.Size(354, 23);
            this.Timestamp_textBox.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "timestamp:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ReferenceNo_textBox);
            this.groupBox2.Controls.Add(this.InitToken_button);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.TokenSesji_textBox);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(12, 217);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(458, 117);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Logowanie tokenem";
            // 
            // ReferenceNo_textBox
            // 
            this.ReferenceNo_textBox.Location = new System.Drawing.Point(98, 80);
            this.ReferenceNo_textBox.Name = "ReferenceNo_textBox";
            this.ReferenceNo_textBox.Size = new System.Drawing.Size(354, 23);
            this.ReferenceNo_textBox.TabIndex = 12;
            // 
            // InitToken_button
            // 
            this.InitToken_button.Location = new System.Drawing.Point(6, 22);
            this.InitToken_button.Name = "InitToken_button";
            this.InitToken_button.Size = new System.Drawing.Size(446, 23);
            this.InitToken_button.TabIndex = 2;
            this.InitToken_button.Text = "Loguj się tokenem";
            this.InitToken_button.UseVisualStyleBackColor = true;
            this.InitToken_button.Click += new System.EventHandler(this.InitToken_button_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 15);
            this.label2.TabIndex = 11;
            this.label2.Text = "ReferenceNo:";
            // 
            // TokenSesji_textBox
            // 
            this.TokenSesji_textBox.Location = new System.Drawing.Point(98, 51);
            this.TokenSesji_textBox.Name = "TokenSesji_textBox";
            this.TokenSesji_textBox.Size = new System.Drawing.Size(354, 23);
            this.TokenSesji_textBox.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "token sesji:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.GetStatus2_button);
            this.groupBox3.Controls.Add(this.GetStatus_button);
            this.groupBox3.Controls.Add(this.Status_textBox);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Location = new System.Drawing.Point(12, 340);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(458, 185);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Status sesji wg ReferenceNo";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 92);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(90, 15);
            this.label26.TabIndex = 12;
            this.label26.Text = "czekamy na 315";
            // 
            // GetStatus2_button
            // 
            this.GetStatus2_button.Location = new System.Drawing.Point(6, 51);
            this.GetStatus2_button.Name = "GetStatus2_button";
            this.GetStatus2_button.Size = new System.Drawing.Size(446, 23);
            this.GetStatus2_button.TabIndex = 11;
            this.GetStatus2_button.Text = "Sprawdź common status / Status paczki wysłanej batchem (bez sesji)";
            this.GetStatus2_button.UseVisualStyleBackColor = true;
            this.GetStatus2_button.Click += new System.EventHandler(this.GetStatus2_button_Click);
            // 
            // GetStatus_button
            // 
            this.GetStatus_button.Location = new System.Drawing.Point(6, 22);
            this.GetStatus_button.Name = "GetStatus_button";
            this.GetStatus_button.Size = new System.Drawing.Size(446, 23);
            this.GetStatus_button.TabIndex = 2;
            this.GetStatus_button.Text = "Sprawdź online status";
            this.GetStatus_button.UseVisualStyleBackColor = true;
            this.GetStatus_button.Click += new System.EventHandler(this.GetStatus_button_Click);
            // 
            // Status_textBox
            // 
            this.Status_textBox.Location = new System.Drawing.Point(98, 80);
            this.Status_textBox.Multiline = true;
            this.Status_textBox.Name = "Status_textBox";
            this.Status_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.Status_textBox.Size = new System.Drawing.Size(354, 99);
            this.Status_textBox.TabIndex = 10;
            this.Status_textBox.WordWrap = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 15);
            this.label7.TabIndex = 9;
            this.label7.Text = "Status:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Terminate_button);
            this.groupBox4.Location = new System.Drawing.Point(12, 531);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(458, 64);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Koniec";
            // 
            // Terminate_button
            // 
            this.Terminate_button.Location = new System.Drawing.Point(6, 22);
            this.Terminate_button.Name = "Terminate_button";
            this.Terminate_button.Size = new System.Drawing.Size(446, 23);
            this.Terminate_button.TabIndex = 2;
            this.Terminate_button.Text = "Terminate session";
            this.Terminate_button.UseVisualStyleBackColor = true;
            this.Terminate_button.Click += new System.EventHandler(this.Terminate_button_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.Invoice1_RefNo_textBox);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.Invoice1_Dlg_button);
            this.groupBox5.Controls.Add(this.Invoice1_textBox);
            this.groupBox5.Controls.Add(this.Invoice1_button);
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(677, 117);
            this.groupBox5.TabIndex = 15;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Wysłanie jednej faktury";
            // 
            // Invoice1_RefNo_textBox
            // 
            this.Invoice1_RefNo_textBox.Location = new System.Drawing.Point(98, 83);
            this.Invoice1_RefNo_textBox.Name = "Invoice1_RefNo_textBox";
            this.Invoice1_RefNo_textBox.Size = new System.Drawing.Size(354, 23);
            this.Invoice1_RefNo_textBox.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "ElementRefNo:";
            // 
            // Invoice1_Dlg_button
            // 
            this.Invoice1_Dlg_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Invoice1_Dlg_button.Location = new System.Drawing.Point(638, 20);
            this.Invoice1_Dlg_button.Name = "Invoice1_Dlg_button";
            this.Invoice1_Dlg_button.Size = new System.Drawing.Size(33, 23);
            this.Invoice1_Dlg_button.TabIndex = 4;
            this.Invoice1_Dlg_button.Text = "...";
            this.Invoice1_Dlg_button.UseVisualStyleBackColor = true;
            this.Invoice1_Dlg_button.Click += new System.EventHandler(this.Invoice1_Dlg_button_Click);
            // 
            // Invoice1_textBox
            // 
            this.Invoice1_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Invoice1_textBox.Location = new System.Drawing.Point(6, 22);
            this.Invoice1_textBox.Name = "Invoice1_textBox";
            this.Invoice1_textBox.Size = new System.Drawing.Size(626, 23);
            this.Invoice1_textBox.TabIndex = 3;
            // 
            // Invoice1_button
            // 
            this.Invoice1_button.Location = new System.Drawing.Point(6, 54);
            this.Invoice1_button.Name = "Invoice1_button";
            this.Invoice1_button.Size = new System.Drawing.Size(446, 23);
            this.Invoice1_button.TabIndex = 2;
            this.Invoice1_button.Text = "Wyślij";
            this.Invoice1_button.UseVisualStyleBackColor = true;
            this.Invoice1_button.Click += new System.EventHandler(this.Invoice1_button_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.Controls.Add(this.GetInvoice1_CorrReason_textBox);
            this.groupBox7.Controls.Add(this.label25);
            this.groupBox7.Controls.Add(this.GetInvoice1_CorrNumber_textBox);
            this.groupBox7.Controls.Add(this.label24);
            this.groupBox7.Controls.Add(this.GetInvoice1AndCorrect_button);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.GetInvoice1_FileName_button);
            this.groupBox7.Controls.Add(this.KSefRefNo_textBox);
            this.groupBox7.Controls.Add(this.GetInvoice_FileName_textBox);
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.Controls.Add(this.GetInvoice1_button);
            this.groupBox7.Controls.Add(this.GetInvoice1_textBox);
            this.groupBox7.Controls.Add(this.label9);
            this.groupBox7.Location = new System.Drawing.Point(6, 303);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(677, 280);
            this.groupBox7.TabIndex = 15;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Pobranie faktury wg ElementRefNo";
            // 
            // GetInvoice1_CorrReason_textBox
            // 
            this.GetInvoice1_CorrReason_textBox.Location = new System.Drawing.Point(471, 103);
            this.GetInvoice1_CorrReason_textBox.Name = "GetInvoice1_CorrReason_textBox";
            this.GetInvoice1_CorrReason_textBox.Size = new System.Drawing.Size(118, 23);
            this.GetInvoice1_CorrReason_textBox.TabIndex = 20;
            this.GetInvoice1_CorrReason_textBox.Text = "Błędnie wystawiona faktura";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(376, 107);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(89, 15);
            this.label25.TabIndex = 19;
            this.label25.Text = "Powód korekty:";
            // 
            // GetInvoice1_CorrNumber_textBox
            // 
            this.GetInvoice1_CorrNumber_textBox.Location = new System.Drawing.Point(252, 103);
            this.GetInvoice1_CorrNumber_textBox.Name = "GetInvoice1_CorrNumber_textBox";
            this.GetInvoice1_CorrNumber_textBox.Size = new System.Drawing.Size(118, 23);
            this.GetInvoice1_CorrNumber_textBox.TabIndex = 18;
            this.GetInvoice1_CorrNumber_textBox.Text = "Kor/2022/0001";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(157, 107);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(89, 15);
            this.label24.TabIndex = 17;
            this.label24.Text = "Numer korekty:";
            // 
            // GetInvoice1AndCorrect_button
            // 
            this.GetInvoice1AndCorrect_button.Location = new System.Drawing.Point(6, 75);
            this.GetInvoice1AndCorrect_button.Name = "GetInvoice1AndCorrect_button";
            this.GetInvoice1AndCorrect_button.Size = new System.Drawing.Size(446, 23);
            this.GetInvoice1AndCorrect_button.TabIndex = 16;
            this.GetInvoice1AndCorrect_button.Text = "Pobierz fakturę i stwórz korektę \"na zero\"";
            this.GetInvoice1AndCorrect_button.UseVisualStyleBackColor = true;
            this.GetInvoice1AndCorrect_button.Click += new System.EventHandler(this.GetInvoice1AndCorrect_button_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 135);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(68, 15);
            this.label22.TabIndex = 15;
            this.label22.Text = "Zapisz jako:";
            // 
            // GetInvoice1_FileName_button
            // 
            this.GetInvoice1_FileName_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GetInvoice1_FileName_button.Location = new System.Drawing.Point(638, 132);
            this.GetInvoice1_FileName_button.Name = "GetInvoice1_FileName_button";
            this.GetInvoice1_FileName_button.Size = new System.Drawing.Size(33, 23);
            this.GetInvoice1_FileName_button.TabIndex = 12;
            this.GetInvoice1_FileName_button.Text = "...";
            this.GetInvoice1_FileName_button.UseVisualStyleBackColor = true;
            this.GetInvoice1_FileName_button.Click += new System.EventHandler(this.GetInvoice1_FileName_button_Click);
            // 
            // KSefRefNo_textBox
            // 
            this.KSefRefNo_textBox.Location = new System.Drawing.Point(98, 22);
            this.KSefRefNo_textBox.Name = "KSefRefNo_textBox";
            this.KSefRefNo_textBox.Size = new System.Drawing.Size(354, 23);
            this.KSefRefNo_textBox.TabIndex = 14;
            // 
            // GetInvoice_FileName_textBox
            // 
            this.GetInvoice_FileName_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GetInvoice_FileName_textBox.Location = new System.Drawing.Point(98, 132);
            this.GetInvoice_FileName_textBox.Name = "GetInvoice_FileName_textBox";
            this.GetInvoice_FileName_textBox.Size = new System.Drawing.Size(534, 23);
            this.GetInvoice_FileName_textBox.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 15);
            this.label10.TabIndex = 13;
            this.label10.Text = "KSeFRefNo:";
            // 
            // GetInvoice1_button
            // 
            this.GetInvoice1_button.Location = new System.Drawing.Point(6, 51);
            this.GetInvoice1_button.Name = "GetInvoice1_button";
            this.GetInvoice1_button.Size = new System.Drawing.Size(446, 23);
            this.GetInvoice1_button.TabIndex = 2;
            this.GetInvoice1_button.Text = "Pobierz fakturę";
            this.GetInvoice1_button.UseVisualStyleBackColor = true;
            this.GetInvoice1_button.Click += new System.EventHandler(this.GetInvoice1_button_Click);
            // 
            // GetInvoice1_textBox
            // 
            this.GetInvoice1_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GetInvoice1_textBox.Location = new System.Drawing.Point(98, 161);
            this.GetInvoice1_textBox.Multiline = true;
            this.GetInvoice1_textBox.Name = "GetInvoice1_textBox";
            this.GetInvoice1_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.GetInvoice1_textBox.Size = new System.Drawing.Size(573, 113);
            this.GetInvoice1_textBox.TabIndex = 10;
            this.GetInvoice1_textBox.WordWrap = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 164);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 15);
            this.label9.TabIndex = 9;
            this.label9.Text = "Faktura/Korekta:";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(476, 94);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(694, 634);
            this.tabControl1.TabIndex = 16;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(686, 606);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Wysyłanie pojedynczych faktur";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.InvoiceStatus_button);
            this.groupBox6.Controls.Add(this.InvoiceStatus_textBox);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Location = new System.Drawing.Point(6, 129);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(677, 168);
            this.groupBox6.TabIndex = 16;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Status faktury wg ElementRefNo";
            // 
            // InvoiceStatus_button
            // 
            this.InvoiceStatus_button.Location = new System.Drawing.Point(6, 22);
            this.InvoiceStatus_button.Name = "InvoiceStatus_button";
            this.InvoiceStatus_button.Size = new System.Drawing.Size(446, 23);
            this.InvoiceStatus_button.TabIndex = 2;
            this.InvoiceStatus_button.Text = "Sprawdź status";
            this.InvoiceStatus_button.UseVisualStyleBackColor = true;
            this.InvoiceStatus_button.Click += new System.EventHandler(this.InvoiceStatus_button_Click_2);
            // 
            // InvoiceStatus_textBox
            // 
            this.InvoiceStatus_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.InvoiceStatus_textBox.Location = new System.Drawing.Point(98, 54);
            this.InvoiceStatus_textBox.Multiline = true;
            this.InvoiceStatus_textBox.Name = "InvoiceStatus_textBox";
            this.InvoiceStatus_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.InvoiceStatus_textBox.Size = new System.Drawing.Size(573, 99);
            this.InvoiceStatus_textBox.TabIndex = 10;
            this.InvoiceStatus_textBox.WordWrap = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 15);
            this.label8.TabIndex = 9;
            this.label8.Text = "Status:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(686, 606);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Odpytywanie";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox8.Controls.Add(this.QueryHeader_Subject2_radioButton);
            this.groupBox8.Controls.Add(this.QueryHeader_Subject1_radioButton);
            this.groupBox8.Controls.Add(this.QueryHeader_PageNo_numericUpDown);
            this.groupBox8.Controls.Add(this.label19);
            this.groupBox8.Controls.Add(this.QueryHeader_textBox);
            this.groupBox8.Controls.Add(this.QueryHeader_button);
            this.groupBox8.Controls.Add(this.QueryHeader_ToDate_dateTimePicker);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Controls.Add(this.QueryHeader_FromDate_dateTimePicker);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Location = new System.Drawing.Point(6, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(674, 594);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Lista faktur z okresu (Invoicing date)";
            // 
            // QueryHeader_Subject2_radioButton
            // 
            this.QueryHeader_Subject2_radioButton.AutoSize = true;
            this.QueryHeader_Subject2_radioButton.Checked = true;
            this.QueryHeader_Subject2_radioButton.Location = new System.Drawing.Point(325, 54);
            this.QueryHeader_Subject2_radioButton.Name = "QueryHeader_Subject2_radioButton";
            this.QueryHeader_Subject2_radioButton.Size = new System.Drawing.Size(119, 19);
            this.QueryHeader_Subject2_radioButton.TabIndex = 16;
            this.QueryHeader_Subject2_radioButton.TabStop = true;
            this.QueryHeader_Subject2_radioButton.Text = "Zakup/otrzymane";
            this.QueryHeader_Subject2_radioButton.UseVisualStyleBackColor = true;
            // 
            // QueryHeader_Subject1_radioButton
            // 
            this.QueryHeader_Subject1_radioButton.AutoSize = true;
            this.QueryHeader_Subject1_radioButton.Location = new System.Drawing.Point(201, 54);
            this.QueryHeader_Subject1_radioButton.Name = "QueryHeader_Subject1_radioButton";
            this.QueryHeader_Subject1_radioButton.Size = new System.Drawing.Size(118, 19);
            this.QueryHeader_Subject1_radioButton.TabIndex = 15;
            this.QueryHeader_Subject1_radioButton.Text = "Sprzedaż/wysłane";
            this.QueryHeader_Subject1_radioButton.UseVisualStyleBackColor = true;
            // 
            // QueryHeader_PageNo_numericUpDown
            // 
            this.QueryHeader_PageNo_numericUpDown.Location = new System.Drawing.Point(66, 53);
            this.QueryHeader_PageNo_numericUpDown.Name = "QueryHeader_PageNo_numericUpDown";
            this.QueryHeader_PageNo_numericUpDown.Size = new System.Drawing.Size(101, 23);
            this.QueryHeader_PageNo_numericUpDown.TabIndex = 14;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 55);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 15);
            this.label19.TabIndex = 13;
            this.label19.Text = "Strona:";
            // 
            // QueryHeader_textBox
            // 
            this.QueryHeader_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.QueryHeader_textBox.Location = new System.Drawing.Point(6, 111);
            this.QueryHeader_textBox.Multiline = true;
            this.QueryHeader_textBox.Name = "QueryHeader_textBox";
            this.QueryHeader_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.QueryHeader_textBox.Size = new System.Drawing.Size(662, 477);
            this.QueryHeader_textBox.TabIndex = 12;
            this.QueryHeader_textBox.WordWrap = false;
            // 
            // QueryHeader_button
            // 
            this.QueryHeader_button.Location = new System.Drawing.Point(6, 82);
            this.QueryHeader_button.Name = "QueryHeader_button";
            this.QueryHeader_button.Size = new System.Drawing.Size(446, 23);
            this.QueryHeader_button.TabIndex = 9;
            this.QueryHeader_button.Text = "Pobierz";
            this.QueryHeader_button.UseVisualStyleBackColor = true;
            this.QueryHeader_button.Click += new System.EventHandler(this.QueryHeader_button_Click);
            // 
            // QueryHeader_ToDate_dateTimePicker
            // 
            this.QueryHeader_ToDate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.QueryHeader_ToDate_dateTimePicker.Location = new System.Drawing.Point(258, 22);
            this.QueryHeader_ToDate_dateTimePicker.Name = "QueryHeader_ToDate_dateTimePicker";
            this.QueryHeader_ToDate_dateTimePicker.Size = new System.Drawing.Size(101, 23);
            this.QueryHeader_ToDate_dateTimePicker.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(201, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 15);
            this.label12.TabIndex = 2;
            this.label12.Text = "Do dnia:";
            // 
            // QueryHeader_FromDate_dateTimePicker
            // 
            this.QueryHeader_FromDate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.QueryHeader_FromDate_dateTimePicker.Location = new System.Drawing.Point(66, 22);
            this.QueryHeader_FromDate_dateTimePicker.Name = "QueryHeader_FromDate_dateTimePicker";
            this.QueryHeader_FromDate_dateTimePicker.Size = new System.Drawing.Size(101, 23);
            this.QueryHeader_FromDate_dateTimePicker.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 28);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 15);
            this.label11.TabIndex = 0;
            this.label11.Text = "Od dnia:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox11);
            this.tabPage4.Controls.Add(this.groupBox10);
            this.tabPage4.Controls.Add(this.groupBox9);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(686, 606);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Pobieranie plików";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox11.Controls.Add(this.label18);
            this.groupBox11.Controls.Add(this.QueryFiles_File_button);
            this.groupBox11.Controls.Add(this.QueryFiles_File_textBox);
            this.groupBox11.Controls.Add(this.QueryFiles_Get_button);
            this.groupBox11.Location = new System.Drawing.Point(3, 364);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(677, 94);
            this.groupBox11.TabIndex = 17;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Pobieranie faktur";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 24);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(85, 15);
            this.label18.TabIndex = 11;
            this.label18.Text = "Plik wynikowy:";
            // 
            // QueryFiles_File_button
            // 
            this.QueryFiles_File_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.QueryFiles_File_button.Location = new System.Drawing.Point(638, 19);
            this.QueryFiles_File_button.Name = "QueryFiles_File_button";
            this.QueryFiles_File_button.Size = new System.Drawing.Size(33, 23);
            this.QueryFiles_File_button.TabIndex = 4;
            this.QueryFiles_File_button.Text = "...";
            this.QueryFiles_File_button.UseVisualStyleBackColor = true;
            this.QueryFiles_File_button.Click += new System.EventHandler(this.QueryFiles_File_button_Click);
            // 
            // QueryFiles_File_textBox
            // 
            this.QueryFiles_File_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.QueryFiles_File_textBox.Location = new System.Drawing.Point(98, 20);
            this.QueryFiles_File_textBox.Name = "QueryFiles_File_textBox";
            this.QueryFiles_File_textBox.Size = new System.Drawing.Size(534, 23);
            this.QueryFiles_File_textBox.TabIndex = 3;
            // 
            // QueryFiles_Get_button
            // 
            this.QueryFiles_Get_button.Location = new System.Drawing.Point(6, 54);
            this.QueryFiles_Get_button.Name = "QueryFiles_Get_button";
            this.QueryFiles_Get_button.Size = new System.Drawing.Size(538, 23);
            this.QueryFiles_Get_button.TabIndex = 2;
            this.QueryFiles_Get_button.Text = "pobierz";
            this.QueryFiles_Get_button.UseVisualStyleBackColor = true;
            this.QueryFiles_Get_button.Click += new System.EventHandler(this.QueryFiles_Get_button_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox10.Controls.Add(this.QueryFiles_Status_button);
            this.groupBox10.Controls.Add(this.QueryFiles_Status_textBox);
            this.groupBox10.Controls.Add(this.label16);
            this.groupBox10.Location = new System.Drawing.Point(3, 126);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(677, 232);
            this.groupBox10.TabIndex = 16;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Status faktury wg QueryElementReferenceNumber :";
            // 
            // QueryFiles_Status_button
            // 
            this.QueryFiles_Status_button.Location = new System.Drawing.Point(6, 22);
            this.QueryFiles_Status_button.Name = "QueryFiles_Status_button";
            this.QueryFiles_Status_button.Size = new System.Drawing.Size(564, 23);
            this.QueryFiles_Status_button.TabIndex = 2;
            this.QueryFiles_Status_button.Text = "Sprawdź status";
            this.QueryFiles_Status_button.UseVisualStyleBackColor = true;
            this.QueryFiles_Status_button.Click += new System.EventHandler(this.QueryFiles_Status_button_Click);
            // 
            // QueryFiles_Status_textBox
            // 
            this.QueryFiles_Status_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.QueryFiles_Status_textBox.Location = new System.Drawing.Point(98, 54);
            this.QueryFiles_Status_textBox.Multiline = true;
            this.QueryFiles_Status_textBox.Name = "QueryFiles_Status_textBox";
            this.QueryFiles_Status_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.QueryFiles_Status_textBox.Size = new System.Drawing.Size(573, 172);
            this.QueryFiles_Status_textBox.TabIndex = 10;
            this.QueryFiles_Status_textBox.WordWrap = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 51);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(42, 15);
            this.label16.TabIndex = 9;
            this.label16.Text = "Status:";
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox9.Controls.Add(this.QueryFiles_RefNo_textBox);
            this.groupBox9.Controls.Add(this.label15);
            this.groupBox9.Controls.Add(this.QueryFiles_Init_button);
            this.groupBox9.Controls.Add(this.QueryFiles_ToDate_dateTimePicker);
            this.groupBox9.Controls.Add(this.label13);
            this.groupBox9.Controls.Add(this.QueryFiles_FromDate_dateTimePicker);
            this.groupBox9.Controls.Add(this.label14);
            this.groupBox9.Location = new System.Drawing.Point(3, 3);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(674, 117);
            this.groupBox9.TabIndex = 14;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Incrementalne pobranie plików (AcquisitionTimestamp)";
            // 
            // QueryFiles_RefNo_textBox
            // 
            this.QueryFiles_RefNo_textBox.Location = new System.Drawing.Point(201, 80);
            this.QueryFiles_RefNo_textBox.Name = "QueryFiles_RefNo_textBox";
            this.QueryFiles_RefNo_textBox.Size = new System.Drawing.Size(354, 23);
            this.QueryFiles_RefNo_textBox.TabIndex = 13;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(184, 15);
            this.label15.TabIndex = 10;
            this.label15.Text = "QueryElementReferenceNumber :";
            // 
            // QueryFiles_Init_button
            // 
            this.QueryFiles_Init_button.Location = new System.Drawing.Point(6, 51);
            this.QueryFiles_Init_button.Name = "QueryFiles_Init_button";
            this.QueryFiles_Init_button.Size = new System.Drawing.Size(564, 23);
            this.QueryFiles_Init_button.TabIndex = 9;
            this.QueryFiles_Init_button.Text = "Init";
            this.QueryFiles_Init_button.UseVisualStyleBackColor = true;
            this.QueryFiles_Init_button.Click += new System.EventHandler(this.QueryFiles_Init_button_Click_1);
            // 
            // QueryFiles_ToDate_dateTimePicker
            // 
            this.QueryFiles_ToDate_dateTimePicker.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.QueryFiles_ToDate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.QueryFiles_ToDate_dateTimePicker.Location = new System.Drawing.Point(281, 22);
            this.QueryFiles_ToDate_dateTimePicker.Name = "QueryFiles_ToDate_dateTimePicker";
            this.QueryFiles_ToDate_dateTimePicker.Size = new System.Drawing.Size(150, 23);
            this.QueryFiles_ToDate_dateTimePicker.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(224, 28);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 15);
            this.label13.TabIndex = 2;
            this.label13.Text = "Do dnia:";
            // 
            // QueryFiles_FromDate_dateTimePicker
            // 
            this.QueryFiles_FromDate_dateTimePicker.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.QueryFiles_FromDate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.QueryFiles_FromDate_dateTimePicker.Location = new System.Drawing.Point(66, 22);
            this.QueryFiles_FromDate_dateTimePicker.Name = "QueryFiles_FromDate_dateTimePicker";
            this.QueryFiles_FromDate_dateTimePicker.Size = new System.Drawing.Size(152, 23);
            this.QueryFiles_FromDate_dateTimePicker.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 28);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 15);
            this.label14.TabIndex = 0;
            this.label14.Text = "Od dnia:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox13);
            this.tabPage3.Controls.Add(this.groupBox12);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(686, 606);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Wysyłanie batch-em (nie wymaga sesji)";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox13.Controls.Add(this.label21);
            this.groupBox13.Controls.Add(this.Batch_SignFile_button);
            this.groupBox13.Controls.Add(this.Batch_SignFile_textBox);
            this.groupBox13.Controls.Add(this.Batch_Send_button);
            this.groupBox13.Location = new System.Drawing.Point(3, 118);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(680, 84);
            this.groupBox13.TabIndex = 20;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Wysłanie podpisanego pliku";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(8, 23);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(110, 15);
            this.label21.TabIndex = 19;
            this.label21.Text = "Podpisany plik xml:";
            // 
            // Batch_SignFile_button
            // 
            this.Batch_SignFile_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Batch_SignFile_button.Location = new System.Drawing.Point(640, 18);
            this.Batch_SignFile_button.Name = "Batch_SignFile_button";
            this.Batch_SignFile_button.Size = new System.Drawing.Size(33, 23);
            this.Batch_SignFile_button.TabIndex = 18;
            this.Batch_SignFile_button.Text = "...";
            this.Batch_SignFile_button.UseVisualStyleBackColor = true;
            this.Batch_SignFile_button.Click += new System.EventHandler(this.Batch_SignFile_button_Click);
            // 
            // Batch_SignFile_textBox
            // 
            this.Batch_SignFile_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Batch_SignFile_textBox.Location = new System.Drawing.Point(134, 19);
            this.Batch_SignFile_textBox.Name = "Batch_SignFile_textBox";
            this.Batch_SignFile_textBox.Size = new System.Drawing.Size(500, 23);
            this.Batch_SignFile_textBox.TabIndex = 17;
            // 
            // Batch_Send_button
            // 
            this.Batch_Send_button.Location = new System.Drawing.Point(6, 48);
            this.Batch_Send_button.Name = "Batch_Send_button";
            this.Batch_Send_button.Size = new System.Drawing.Size(564, 23);
            this.Batch_Send_button.TabIndex = 14;
            this.Batch_Send_button.Text = "Wyslij podpisany plik i części pliku .zip";
            this.Batch_Send_button.UseVisualStyleBackColor = true;
            this.Batch_Send_button.Click += new System.EventHandler(this.Batch_Send_button_Click);
            // 
            // groupBox12
            // 
            this.groupBox12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox12.Controls.Add(this.label23);
            this.groupBox12.Controls.Add(this.Batch_MaxSize_numericUpDown);
            this.groupBox12.Controls.Add(this.label17);
            this.groupBox12.Controls.Add(this.label20);
            this.groupBox12.Controls.Add(this.Batch_ZipFile_button);
            this.groupBox12.Controls.Add(this.Batch_ZipFile_textBox);
            this.groupBox12.Controls.Add(this.Batch_Init_button);
            this.groupBox12.Location = new System.Drawing.Point(3, 3);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(680, 109);
            this.groupBox12.TabIndex = 0;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Tworzenie pliku xml do podpisu:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(195, 53);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(79, 15);
            this.label23.TabIndex = 22;
            this.label23.Text = "KB (do 50MB)";
            // 
            // Batch_MaxSize_numericUpDown
            // 
            this.Batch_MaxSize_numericUpDown.Location = new System.Drawing.Point(134, 48);
            this.Batch_MaxSize_numericUpDown.Maximum = new decimal(new int[] {
            50000,
            0,
            0,
            0});
            this.Batch_MaxSize_numericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Batch_MaxSize_numericUpDown.Name = "Batch_MaxSize_numericUpDown";
            this.Batch_MaxSize_numericUpDown.Size = new System.Drawing.Size(55, 23);
            this.Batch_MaxSize_numericUpDown.TabIndex = 21;
            this.Batch_MaxSize_numericUpDown.Value = new decimal(new int[] {
            25,
            0,
            0,
            0});
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 50);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(115, 15);
            this.label17.TabIndex = 20;
            this.label17.Text = "Max wielkość części:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(8, 23);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 15);
            this.label20.TabIndex = 19;
            this.label20.Text = "Plik zip z plikami xml:";
            // 
            // Batch_ZipFile_button
            // 
            this.Batch_ZipFile_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Batch_ZipFile_button.Location = new System.Drawing.Point(640, 18);
            this.Batch_ZipFile_button.Name = "Batch_ZipFile_button";
            this.Batch_ZipFile_button.Size = new System.Drawing.Size(33, 23);
            this.Batch_ZipFile_button.TabIndex = 18;
            this.Batch_ZipFile_button.Text = "...";
            this.Batch_ZipFile_button.UseVisualStyleBackColor = true;
            this.Batch_ZipFile_button.Click += new System.EventHandler(this.Batch_ZipFile_button_Click);
            // 
            // Batch_ZipFile_textBox
            // 
            this.Batch_ZipFile_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Batch_ZipFile_textBox.Location = new System.Drawing.Point(134, 19);
            this.Batch_ZipFile_textBox.Name = "Batch_ZipFile_textBox";
            this.Batch_ZipFile_textBox.Size = new System.Drawing.Size(500, 23);
            this.Batch_ZipFile_textBox.TabIndex = 17;
            // 
            // Batch_Init_button
            // 
            this.Batch_Init_button.Location = new System.Drawing.Point(8, 77);
            this.Batch_Init_button.Name = "Batch_Init_button";
            this.Batch_Init_button.Size = new System.Drawing.Size(562, 23);
            this.Batch_Init_button.TabIndex = 14;
            this.Batch_Init_button.Text = "Dziel plik .zip na części i twórz plik .xml do podpisania";
            this.Batch_Init_button.UseVisualStyleBackColor = true;
            this.Batch_Init_button.Click += new System.EventHandler(this.Batch_Init_button_Click);
            // 
            // Configuration_button
            // 
            this.Configuration_button.Location = new System.Drawing.Point(14, 42);
            this.Configuration_button.Name = "Configuration_button";
            this.Configuration_button.Size = new System.Drawing.Size(75, 23);
            this.Configuration_button.TabIndex = 17;
            this.Configuration_button.Text = "Zmień...";
            this.Configuration_button.UseVisualStyleBackColor = true;
            this.Configuration_button.Click += new System.EventHandler(this.Configuration_button_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1194, 740);
            this.Controls.Add(this.Configuration_button);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Configuration_listBox);
            this.Controls.Add(this.label1);
            this.Name = "MainForm";
            this.Text = "KSeF by Gbb Software";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.MainForm_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.configurationBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.QueryHeader_PageNo_numericUpDown)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Batch_MaxSize_numericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private ListBox Configuration_listBox;
        private BindingSource configurationBindingSource;
        private Button AuthorisationChallenge_button;
        private GroupBox groupBox1;
        private TextBox Challenge_textBox;
        private Label label4;
        private TextBox Timestamp_textBox;
        private Label label3;
        private GroupBox groupBox2;
        private Button InitToken_button;
        private TextBox ReferenceNo_textBox;
        private Label label2;
        private TextBox TokenSesji_textBox;
        private Label label5;
        private GroupBox groupBox3;
        private Button GetStatus_button;
        private TextBox Status_textBox;
        private Label label7;
        private Button GetStatus2_button;
        private GroupBox groupBox4;
        private Button Terminate_button;
        private GroupBox groupBox5;
        private TextBox Invoice1_textBox;
        private Button Invoice1_button;
        private Button Invoice1_Dlg_button;
        private TextBox Invoice1_RefNo_textBox;
        private Label label6;
        private GroupBox groupBox7;
        private Button GetInvoice1_button;
        private TextBox GetInvoice1_textBox;
        private Label label9;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TextBox KSefRefNo_textBox;
        private Label label10;
        private GroupBox groupBox8;
        private TextBox QueryHeader_textBox;
        private Button QueryHeader_button;
        private DateTimePicker QueryHeader_ToDate_dateTimePicker;
        private Label label12;
        private DateTimePicker QueryHeader_FromDate_dateTimePicker;
        private Label label11;
        private TabPage tabPage4;
        private GroupBox groupBox6;
        private Button InvoiceStatus_button;
        private TextBox InvoiceStatus_textBox;
        private Label label8;
        private GroupBox groupBox9;
        private Button QueryFiles_Init_button;
        private DateTimePicker QueryFiles_ToDate_dateTimePicker;
        private Label label13;
        private DateTimePicker QueryFiles_FromDate_dateTimePicker;
        private Label label14;
        private GroupBox groupBox10;
        private Button QueryFiles_Status_button;
        private TextBox QueryFiles_Status_textBox;
        private Label label16;
        private GroupBox groupBox11;
        private Label label18;
        private Button QueryFiles_File_button;
        private TextBox QueryFiles_File_textBox;
        private Button QueryFiles_Get_button;
        private GroupBox groupBox12;
        private Button Batch_Init_button;
        private NumericUpDown QueryHeader_PageNo_numericUpDown;
        private Label label19;
        private GroupBox groupBox13;
        private Label label21;
        private Button Batch_SignFile_button;
        private TextBox Batch_SignFile_textBox;
        private Button Batch_Send_button;
        private Label label23;
        private NumericUpDown Batch_MaxSize_numericUpDown;
        private Label label17;
        private Label label20;
        private Button Batch_ZipFile_button;
        private TextBox Batch_ZipFile_textBox;
        private TextBox QueryFiles_RefNo_textBox;
        private Label label15;
        private RadioButton QueryHeader_Subject2_radioButton;
        private RadioButton QueryHeader_Subject1_radioButton;
        private Label label22;
        private Button GetInvoice1_FileName_button;
        private TextBox GetInvoice_FileName_textBox;
        private Button GetInvoice1AndCorrect_button;
        private TextBox GetInvoice1_CorrReason_textBox;
        private Label label25;
        private TextBox GetInvoice1_CorrNumber_textBox;
        private Label label24;
        private Label label26;
        private Button Configuration_button;
    }
}